# 悬浮通知磁贴

主要使用 NotificationListenerService，遵循 GUN GPL 3.0 协议开源，由 LingC 开发。

酷安链接：<https://www.coolapk.com/apk/239909> 



<img src="https://github.com/HelloLingC/floating-tile/blob/master/screenshot/1.png" alt="截图1"  width="352" height="811">



# License

> ```
>     This program is free software: you can redistribute it and/or modify
>     it under the terms of the GNU General Public License as published by
>     the Free Software Foundation, either version 3 of the License, or
>     (at your option) any later version.
> 
>     This program is distributed in the hope that it will be useful,
>     but WITHOUT ANY WARRANTY; without even the implied warranty of
>     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
>     GNU General Public License for more details.
> 
>     You should have received a copy of the GNU General Public License
>     along with this program.  If not, see <https://www.gnu.org/licenses/>.
> ```