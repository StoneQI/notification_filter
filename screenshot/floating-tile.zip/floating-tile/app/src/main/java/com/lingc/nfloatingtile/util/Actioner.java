package com.lingc.nfloatingtile.util;

public enum Actioner{FLOAT_TITLE,NOACTION};
