package com.lingc.nfloatingtile.dialogapppicker;

import com.lingc.nfloatingtile.dialogapppicker.objects.ShortcutItem;

/**
 * Created by Paul on 12/07/15.
 */
public interface ShortcutCreatedListener {
    void onShortcutCreated(ShortcutItem item);
}
