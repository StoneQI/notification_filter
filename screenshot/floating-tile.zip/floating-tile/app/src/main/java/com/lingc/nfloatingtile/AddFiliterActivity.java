package com.lingc.nfloatingtile;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;

import com.lingc.nfloatingtile.util.NotificationFilterManager;
import com.lingc.nfloatingtile.entitys.NotificationMatcher;
import com.lingc.nfloatingtile.dialogapppicker.DialogAppPicker;
import com.lingc.nfloatingtile.dialogapppicker.objects.AppItem;
import com.lingc.nfloatingtile.dialogapppicker.objects.ShortcutItem;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class AddFiliterActivity extends AppCompatActivity {
    private final static  String TAG ="AddFiliterActivity";

    private NotificationMatcher notificationMatcher =null;
    private Set<String> packageNames = null;
    private int notificationID = -1;
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_filiter);

        final EditText filter_id =(EditText)findViewById(R.id.filter_ID);
        final EditText filter_name =(EditText)findViewById(R.id.filter_name);
        final EditText filter_tiitle_match =(EditText)findViewById(R.id.filter_tiitle_match);
        final EditText filter_content_match =(EditText)findViewById(R.id.filter_content_match);
        final EditText filter_tiitle_extra =(EditText)findViewById(R.id.filter_tiitle_extra);
        final EditText filter_title_replace =(EditText)findViewById(R.id.filter_title_replace);
        final EditText filter_content_extra =(EditText)findViewById(R.id.filter_content_extra);
        final EditText filter_content_replace =(EditText)findViewById(R.id.filter_content_replace);
        final Button update_notification = (Button)findViewById(R.id.update_notification);
        final Button  detele_notification = (Button)findViewById(R.id.delete_notification);

        final Switch isBreak =(Switch) findViewById(R.id.isBreak);

        final Spinner actioner =(Spinner)findViewById(R.id.actioner);

        Intent intent = getIntent();
         notificationID = intent.getIntExtra("ID",-1);
        Log.e(TAG, "ID:"+String.valueOf(notificationID));
        if(notificationID != -1){
            notificationMatcher = NotificationFilterManager.getInstance().getNotificationMatcher(notificationID,getApplicationContext());
            filter_id.setText(String.valueOf(notificationMatcher.ID));
            filter_name.setText(notificationMatcher.name);
            filter_tiitle_match.setText(notificationMatcher.titlePattern);
            filter_content_match.setText(notificationMatcher.contextPatter);
            filter_tiitle_extra.setText(notificationMatcher.titleFiliter);
            filter_title_replace.setText(notificationMatcher.titleFiliterReplace);
            filter_content_extra.setText(notificationMatcher.contextFiliter);
            filter_content_replace.setText(notificationMatcher.contextFiliterReplace);
            packageNames  = new HashSet<>(notificationMatcher.packageNames);
            isBreak.setChecked(notificationMatcher.breakDown);
//            String[] actioners = getResources().getStringArray(R.id.actioner);
            actioner.setSelection(notificationMatcher.actioner);

        }else {
            update_notification.setText("添加");
            notificationMatcher = new NotificationMatcher();
            packageNames = new HashSet<>(notificationMatcher.packageNames);
            notificationMatcher.ID = NotificationFilterManager.getInstance().getNextID(AddFiliterActivity.this);
            filter_id.setText(String.valueOf(notificationMatcher.ID));
        }


        update_notification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (filter_id.getText().toString().length() ==0 || filter_name.getText().toString().length()==0){
                    new AlertDialog.Builder(AddFiliterActivity.this)
                            .setTitle("提醒")
                            .setMessage("规则ID和规则名称不能为空")
                            .setPositiveButton("关闭", null)
                            .show();
//                    v.setEnabled(true);
                    return;
                }
                v.setEnabled(false);
                notificationMatcher.ID = Integer.parseInt(filter_id.getText().toString());
                notificationMatcher.name = filter_name.getText().toString();
                notificationMatcher.titlePattern =filter_tiitle_match.getText().toString();
                notificationMatcher.contextPatter =filter_content_match.getText().toString();
                notificationMatcher.titleFiliter =filter_tiitle_extra.getText().toString();
                notificationMatcher.titleFiliterReplace =filter_title_replace.getText().toString();
                notificationMatcher.contextFiliter =filter_content_extra.getText().toString();
                notificationMatcher.contextFiliterReplace =filter_content_replace.getText().toString();
                notificationMatcher.breakDown = isBreak.isChecked();
                notificationMatcher.actioner = actioner.getSelectedItemPosition();
                if (packageNames.size() !=0){
                    notificationMatcher.packageNames =new ArrayList(packageNames) ;
                }
//                if (notificationMatcher.ID.&& notificationMatcher.name ==null){
//
//                }

                if(notificationID == -1){

                    if (NotificationFilterManager.getInstance().addNotificationMatch(notificationMatcher,AddFiliterActivity.this)){
                        new AlertDialog.Builder(AddFiliterActivity.this)
                                .setTitle("提醒")
                                .setMessage("添加成功")
                                .setPositiveButton("继续添加", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        notificationMatcher.ID = NotificationFilterManager.getInstance().getNextID(AddFiliterActivity.this);
                                        filter_id.setText(String.valueOf(notificationMatcher.ID));
                                        dialog.dismiss();
                                    }
                                })
                                .setNegativeButton("返回列表", new DialogInterface.OnClickListener(){

                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                        finish();
                                    }
                                })
                                .show();
//                        Toast.makeText(AddFiliterActivity.this, "添加成功", Toast.LENGTH_SHORT).show();
                    }else{
                        new AlertDialog.Builder(AddFiliterActivity.this)
                                .setTitle("提醒")
                                .setMessage("添加失败")
                                .setPositiveButton("关闭", null)
                                .show();
//                        Toast.makeText(AddFiliterActivity.this, "修改失败", Toast.LENGTH_SHORT).show();
                    }

                }else {
                    if (NotificationFilterManager.getInstance().updateNotificationMatch(notificationID,notificationMatcher,AddFiliterActivity.this)){
                        new AlertDialog.Builder(AddFiliterActivity.this)
                                .setTitle("提醒")
                                .setMessage("修改成功")
                                .setPositiveButton("再次修改", null)
                                .setNegativeButton("返回列表", new DialogInterface.OnClickListener(){

                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                        finish();
                                    }
                                })
                                .show();
//                        Toast.makeText(AddFiliterActivity.this, "修改成功", Toast.LENGTH_SHORT).show();
                    }else{
                        new AlertDialog.Builder(AddFiliterActivity.this)
                                .setTitle("提醒")
                                .setMessage("修改失败")
                                .setPositiveButton("关闭", null)
                                .show();
//                        Toast.makeText(AddFiliterActivity.this, "修改失败", Toast.LENGTH_SHORT).show();
                    }
                }
                v.setEnabled(true);


            }
        });

        detele_notification.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(notificationID != -1){
                    if(NotificationFilterManager.getInstance().deleteNotificationMatch(notificationID,AddFiliterActivity.this)){
                        new AlertDialog.Builder(AddFiliterActivity.this)
                                .setTitle("提醒")
                                .setMessage("删除成功")
                                .setPositiveButton("关闭", null)
                                .show();
                        finish();
                        return;
                    }
                    new AlertDialog.Builder(AddFiliterActivity.this)
                            .setTitle("提醒")
                            .setMessage("删除失败")
                            .setPositiveButton("关闭", null)
                            .show();
//                    Toast.makeText(AddFiliterActivity.this, "删除失败", Toast.LENGTH_SHORT).show();
                }

            }
        });


        findViewById(R.id.appPicker).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e(TAG,"appPicker Clicked");
                DialogAppPicker mDialog = new DialogAppPicker(AddFiliterActivity.this,packageNames);
                mDialog.setOnItemChooseListener(new DialogAppPicker.OnItemChooseListener() {
                    @Override
                    public void onAppSelected(AppItem item) {
                        if (packageNames.contains(item.getPackageName())){
                            packageNames.remove(item.getPackageName());
                        }else {
                            packageNames.add(item.getPackageName());
                        }
                    }

                    @Override
                    public void onShortcutSelected(ShortcutItem item) {
                        // Do something with the shortcut
                    }
                });
                mDialog.getDialog()
                        .setPositiveButton("确定", null)
                        .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                packageNames.clear();
                            }
                        })
                        .create()
                        .show();
                // Don't forget this also
//                @Override
//                public void onActivityResult(int requestCode, int resultCode, Intent data) {
////                    super.onActivityResult(requestCode, resultCode, data);
//                    mDialog.onActivityResult(requestCode, resultCode, data);
//                }
            }
        });
        Log.e(TAG,"start");

    }


}
