package com.lingc.nfloatingtile;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import androidx.core.app.NotificationCompat;
import android.util.Log;

import com.blankj.utilcode.util.AppUtils;
import com.lingc.nfloatingtile.util.NotificationFilterManager;
import com.lingc.nfloatingtile.util.NotificationInfo;
import com.lingc.nfloatingtile.entitys.NotificationMatcher;
import com.lingc.nfloatingtile.util.SpUtil;
import com.lingc.nfloatingtile.widget.FloatingTile;
import com.lingc.nfloatingtile.widget.TileObject;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * Create by LingC on 2019/8/4 21:46
 */
public class NotificationService extends NotificationListenerService {
    private final static  String TAG ="NotificationService";
    private static final String NOTIFICATION_CHANNEL_ID = "FloatWindowService";
    public static final int MANAGER_NOTIFICATION_ID = 0x1001;
    public static final int HANDLER_DETECT_PERMISSION = 0x2001;
    private String content;
    private Icon iconIcon=null;
    private Bitmap iconBitmap = null;
    private ArrayList<NotificationMatcher> systemNotificationMatchers= new ArrayList<NotificationMatcher>();
    private ArrayList<NotificationMatcher> customNotificationMatchers= null;

    @Override
    public void onCreate() {
        super.onCreate();
        Log.e(TAG,"service create");
        customNotificationMatchers = NotificationFilterManager.getInstance().getData(NotificationService.this);
        setSystemNotificationMatchers();
        customNotificationMatchers.addAll(systemNotificationMatchers);
        if (SpUtil.getSp(getApplicationContext(),"appSettings").getBoolean("notification_show", false)){
            addForegroundNotification();
        }
    }

    private void setSystemNotificationMatchers(){
        NotificationMatcher notificationMatcher = new NotificationMatcher();
        notificationMatcher.ID = 0;
        notificationMatcher.actioner = 0;
        systemNotificationMatchers.add(notificationMatcher);
    }

    @Override
    public void onNotificationPosted(final StatusBarNotification sbn) {
        if (!sbn.isClearable() || sbn.getPackageName().equals(getPackageName())
                || sbn.getPackageName().equals("android")) {
            return;
        }
        PowerManager powerManager = (PowerManager) getApplicationContext().getSystemService(Context.POWER_SERVICE);
        if (!powerManager.isScreenOn()) {
            return;
        }

        NotificationInfo notificationInfo = getNotificationInfo(sbn);
        if (notificationInfo.getContent() == null && notificationInfo.getTitle()==null) {
            return;
        }
//        if (TextUtils.isEmpty(title) && TextUtils.isEmpty(content)) {
//            return;
//        }
        Log.e(TAG,notificationInfo.getTitle());
        if (notificationInfo.getContent().contains("下载") || notificationInfo.getContent().contains("%")) {
            return;
        }
//        ArrayList<NotificationMatcher> notificationMatchers = new ArrayList<NotificationMatcher>();
        for(NotificationMatcher notificationMatcher:customNotificationMatchers){
            Log.e(TAG, String.valueOf(notificationMatcher.ID));
            if(  notificationMatcher.packageNames !=null && !notificationMatcher.packageNames.isEmpty() && !notificationMatcher.packageNames.contains(notificationInfo.getPackageName())){
                continue;
            }

            if(notificationMatcher.titlePattern != null && !notificationMatcher.titlePattern.isEmpty() ){
                Pattern p =  Pattern.compile(notificationMatcher.titlePattern);
                if (!p.matcher(notificationInfo.getTitle()).find()) continue;
            }

            if(notificationMatcher.contextPatter != null  && !notificationMatcher.contextPatter.isEmpty() ){
                Pattern p =  Pattern.compile(notificationMatcher.contextPatter);
                if (!p.matcher(notificationInfo.getContent()).find()) continue;
            }

            if( notificationMatcher.titleFiliter != null  &&!notificationMatcher.titleFiliter.isEmpty() ){
                String new_title = "";
                if (notificationMatcher.titleFiliterReplace != null  && !notificationMatcher.titleFiliterReplace.isEmpty()){
                    try {
                        new_title = notificationInfo.getTitle();
                        new_title = new_title.replaceAll(notificationMatcher.titleFiliter,notificationMatcher.titleFiliterReplace);
                    }catch (PatternSyntaxException e){
                        new_title = "";
                        e.printStackTrace();
                    }
                }else {
                    Pattern p =  Pattern.compile(notificationMatcher.titleFiliter);
                    Matcher m = p.matcher(notificationInfo.getTitle());
                    while(m.find()){
                        Log.e(TAG,m.group());
                        new_title = new_title +m.group();
                    }
                }
                if(!new_title.isEmpty()){
                    notificationInfo.setTitle(new_title);
                }
            }
            if(notificationMatcher.contextFiliter != null  && !notificationMatcher.contextFiliter.isEmpty() ){
                String new_Content = "";
                if (notificationMatcher.contextFiliterReplace != null && !notificationMatcher.contextFiliterReplace.isEmpty()){
                    try {
                        new_Content = notificationInfo.getTitle();
                        new_Content.replaceAll(notificationMatcher.contextFiliter,notificationMatcher.contextFiliterReplace);
                    }catch (PatternSyntaxException e){
                        new_Content ="";
                        e.printStackTrace();
                    }
                }else {
                    Pattern p = Pattern.compile(notificationMatcher.contextFiliter);
                    Matcher m = p.matcher(notificationInfo.getContent());
                    while (m.find()) {
                        Log.e(TAG, m.group());
                        new_Content = new_Content + m.group();
                    }
                }
                if (!new_Content.isEmpty()) {
                    notificationInfo.setTitle(new_Content);
                }

            }




            switch (notificationMatcher.actioner){
                case 0:cancelAllNotifications();floatingTileAction(notificationInfo); break;
                case 1:super.onNotificationPosted(sbn);break;
                case 2:cancelAllNotifications(); break;
//                default: cancelAllNotifications();floatingTileAction(notificationInfo); break;
            }
            if(notificationMatcher.breakDown){
                break;
            }
        }
//        cancelAllNotifications();


//        final Object finalIcon = icon;
//        floatingTileAction(notificationInfo);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.e(TAG,"service stop");
    }

    private NotificationInfo getNotificationInfo(StatusBarNotification sbn) {
        Bundle extras = sbn.getNotification().extras;
        NotificationInfo notificationInfo = new NotificationInfo(sbn.getId(),sbn.getKey(),sbn.getPostTime());
        notificationInfo.setClearable(sbn.isClearable());
        notificationInfo.setOnGoing(sbn.isOngoing());
        notificationInfo.setTag(sbn.getTag());
        notificationInfo.setPackageName(sbn.getPackageName());
        notificationInfo.setLargeIcon(sbn.getNotification().getLargeIcon());
        notificationInfo.setSmallIcon(sbn.getNotification().getSmallIcon());
        notificationInfo.setTitle(extras.getString(android.app.Notification.EXTRA_TITLE));
        notificationInfo.setContent(extras.getString(android.app.Notification.EXTRA_TEXT));
        notificationInfo.setIntent(sbn.getNotification().contentIntent);
        return notificationInfo;
    }

    private void floatingTileAction(final NotificationInfo notificationInfo) {
//        new Thread(new Runnable() {
////            @RequiresApi(api = Build.VERSION_CODES.M)
//            @Override
//            public void run() {
                FloatingTile floatingTile = new FloatingTile(notificationInfo);
                floatingTile.setLastTile(TileObject.lastFloatingTile);
                floatingTile.showWindow(NotificationService.this);
//            }
//        }).start();
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        super.onNotificationRemoved(sbn);
    }

    private void addForegroundNotification() {
        createNotificationChannel();

        String contentTitle = "悬浮通知";
        String contentText = "悬浮通知运行中...";

        NotificationCompat.Builder mBuilder = new NotificationCompat.Builder(getApplicationContext(), NOTIFICATION_CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setLargeIcon(BitmapFactory.decodeResource(getResources(),R.mipmap.ic_launcher))
                .setContentTitle(contentTitle)
                .setContentText(contentText)
                .setWhen(System.currentTimeMillis())
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        Intent msgIntent = getStartAppIntent(getApplicationContext());
        PendingIntent mainPendingIntent = PendingIntent.getActivity(getApplicationContext(), 0,
                msgIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        Notification notification = mBuilder.setContentIntent(mainPendingIntent)
                .setAutoCancel(false).build();

        startForeground(MANAGER_NOTIFICATION_ID, notification);
    }
    private Intent getStartAppIntent(Context context) {
        Intent intent = context.getPackageManager()
                .getLaunchIntentForPackage(AppUtils.getAppPackageName());
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        }

        return intent;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Name";
            String description = "Description";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, name, importance);
            channel.setDescription(description);
            channel.setShowBadge(false);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }
    }
}
