package com.lingc.nfloatingtile.entitys;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class NotificationMatcher {
    public  int ID;
    public  String name="";
    public String titlePattern="";
    public String contextPatter="";
    public ArrayList<String> packageNames=new ArrayList<String>();
    public String titleFiliter="";
    public String titleFiliterReplace="";
    public String contextFiliter="";
    public String contextFiliterReplace="";
    public Boolean breakDown =false;
    public int actioner = 0;


}
