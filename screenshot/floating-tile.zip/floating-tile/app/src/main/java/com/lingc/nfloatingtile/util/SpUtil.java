package com.lingc.nfloatingtile.util;

import android.content.Context;
import android.content.SharedPreferences;
import android.nfc.Tag;

/**
 * Create by LingC on 2019/8/6 17:21
 */
public class SpUtil {

    public static SharedPreferences getSp(Context context,String tag) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(tag, Context.MODE_PRIVATE);
        return sharedPreferences;
    }

}
